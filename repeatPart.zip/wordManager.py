# -*- coding: utf-8 -*-
"""
Created on Mon May 10 22:05:23 2021

@author: jimin
"""
import os
from WordInfo import Word
print(os.path.dirname(os.path.realpath(__file__))) #파일 경로 안적어도 됨


class WordManager:
    def __init__(self):
        self.wordlist=[]
        self.wordread()

    def wordread(self) :
    #파일읽기 간략한 코드
        with open('word.txt','r',encoding='UTF8') as f : #close 부분 자동 실행
            lines=f.readlines() #파일전체읽기
            l=[] #list생성
         
            for line in lines : #lines에서 읽은 전체 문자열을 한줄 기준으로 line 리스트에 넣기
                l.append(line.split(',')) #line의 한줄 ','기준으로 자르기 [[1번,영어,한글],...]

            self.wordlist.clear()  
            #Word클래스 word인스턴스통해 호출
            for i in range(len(l)): 
                word=Word()
                word.set_init(int(l[i][0]), l[i][1], l[i][2],'') #번호,영어,한글
                self.wordlist.append(word)