# -*- coding: utf-8 -*-
"""
Created on Sat Apr 24 19:45:10 2021

@author: jimin
"""
import os
from tkinter import *
from rptWord import RptWord    
from userManager import UserManager
print(os.path.dirname(os.path.realpath(__file__)))    
class SampleApp(Tk):
    def __init__(self):
        Tk.__init__(self)
        self.geometry("1000x800")
        self.resizable(False,False)
        
        self._frame = None
        self.switch_frame(StartPage)

    def switch_frame(self, frame_class):
        new_frame = frame_class(self)
        if self._frame is not None:
            self._frame.destroy()
        self._frame = new_frame
        self._frame.pack()

class StartPage(Tk,Frame):
    def __init__(self, master):
        Frame.__init__(self, master)
        bg=Canvas(self,width=880,height=800,bg="white")
        bg.pack()
        #rptInitBg1=PhotoImage(file="rptInitbg1.png",master=self)
        bg.create_text(0,40,anchor='nw',text='rptInitBg1')
        rptWidget1=Label(self,text="복습하기",font=("맑은 고딕",45,),
                            fg="white",bg="#ED7D31",justify="center")
        rptWidget1.place(x=2,y=150,width=880,height=100)
        
        
        rptWidget3=Label(self,text="사용방법",font=("맑은 고딕",10,),width=10,height=1,bg="#9F9F9F")
        rptWidget3.place(x=400,y=250)
        
        #explainButton=PhotoImage(file="questionMark.png",master=self.window)
        B1=Button(self,text="start",bg="#9F9F9F",command=self.howToUse,bd=0)
        B1.place(x=360,y=280)
    
        #startButton=PhotoImage(file="rptStartButton.png",master=self.window)
        B2=Button(self,text="startButton",bg="#9F9F9F",justify="center",bd=0,command=lambda:master.switch_frame(PageOne))
        B2.place(x=335,y=380,width=200,height=200)
    def howToUse(self):
        self.window2=Tk()
        self.window2.geometry("500x400")
        self.window2.resizable(False,False)
        #htulabelphoto=PhotoImage(file="howtouse.png",master=self.window2)
        self.htulabel=Label(self.window2,text="htulabelphoto",bg="white")
        self.htulabel.pack()
        self.window2.mainloop()       
        #tk.Button(self, text="Go to page two",
                  #command=lambda: master.switch_frame(PageTwo)).pack()

class PageOne(Frame,RptWord):
    def __init__(self, master):
        Frame.__init__(self, master)
        RptWord.__init__(self)
        self.EngRdWord=[]
        self.EngRdWord=self.finalRptWord
        self.writtenWord=[] 
        self.rst=[]
        self.count=0
        self.set_frame()

    def set_frame(self):
        bg=Canvas(self,width=880,height=800,bg="#FCD4B4") #4칸 빼면 880
        bg.pack()
        
        #배경 구현
        rpt_widget1=Label(self,text="복습하기",font=("맑은 고딕",40,),fg="white",bg="#ED7D31",justify="center")
        rpt_widget1.place(x=2,y=2,width=880,height=120)
        rpt_widget2=Label(self,bg="#ED7D31")
        rpt_widget2.place(x=2,y=780,width=880,height=10)
        
        #주의 사항 위젯 구현 
        rpt_bg2=Label(self,text="주의: 한글 뜻을 입력한뒤 enter를 눌러주세요",bg="white")
        rpt_bg2.place(x=2,y=390,width=880,height=40)
        
           
        #영어 단어위젯 구현
        self.text=StringVar()
        print(self.text.get())
        #초기 영단어 설정
        self.setWord()
        self.wordWidget=Label(self,textvariable=self.text,font=("맑은 고딕",50,),bg="white",justify="center")
        
        
   
        #단어답 입력박스 구현
        self.txtBox=Entry(self,font=("맑은 고딕",30,),fg="#404040",bg="#A6A6A6",justify="center")
        self.txtBox.place(x=10,y=440,width=860,height=210)
        
        #entry 엔터 이벤트 저장으로 처리
        self.txtBox.bind("<Return>",self.save)
        
        #단어 체크를 위해 랜덤으로 설정한 단어들을 프린트해보고 영어단어위젯 위치 선정
        print(self.EngRdWord)
        self.wordWidget.place(x=10,y=130,width=860,height=250)
        
        
        #다시하기 버튼 구현
        #RtnToInit=PhotoImage(file="restart.png",master=self.window)#master는 init에서 선언되었으므로 self를 이용해서 접근해야됨
        self.rtnToInit=Button(self,text='RtnToInit',bg="#FCD4B4",justify="center",bd=0,command=lambda:self.master.switch_frame(StartPage))
        self.rtnToInit.place(x=2,y=670,width=200,height=100)
        
    #처음영어단어 설정하는 메소드    
    def setWord(self):
        while(1):
            self.text.set(self.EngRdWord[0][1]) 
            return 0
    #영어단어 변경하는 메소드
    #엔터를 치면 writtenword에 입력받은 단어를 저장하고 영어단어를 다음 리스트로 변경한다.            
    def save(self,event):
         self.writtenWord.append(str(self.txtBox.get())+'\n')  #비교할때 용이하게
         self.txtBox.delete(0,"end")
         #self.resultBtImage=PhotoImage(file="resultBtImage.png",master=self.window)
         self.chgWord()
         print("enter pressed:Saved Complete!")
         print(self.writtenWord)   
    
    def chgWord(self):
        while(1):
            for i in range(len(self.EngRdWord)):
                if self.text.get()==self.EngRdWord[i][1]: 
                    self.text.set(self.EngRdWord[i+1][1])
                    print("nxtWord button pressed:moved to next word!")
                    return 0
                elif self.text.get()==self.EngRdWord[-1][1]:
                #다 끝나면 결과보기가 나타남
                    self.resultBt=Button(self,text='self.resultBtImage',bg="#FCD4B4",command=self.result)
                    self.resultBt.place(x=420,y=670,width=150,height=100)
                    print("nxtWord button destoyed:please check the answer")
                    self.cal()
                    return 0
    def cal(self):
         #채점
        for i in range(len(self.EngRdWord)):
            if self.EngRdWord[i][2]==self.writtenWord[i]:
                self.rst.insert(i,'correct')
                self.count=self.count+1
                print('correct')
            else:
                self.rst.insert(i,'wrong')
                print('wrong')           
                
    def result(self):
        self.window2 =Tk()
        self.window2.geometry("800x800")
        self.window2.resizable(False,False) #윈도우 창크기 변경 불가능
        self.frame2=Frame(self.window2)
        self.frame2.pack()
        self.rst_widget1=Canvas(self.frame2,width=800,height=100,bg="#3E78ED")
        self.rst_widget1.pack()
        self.rst_widget1.create_text(400,50,fill="white",text="Result",font=("맑은 고딕",30,))
        self.temp2=Canvas(self.frame2,width=800,height=800,bg="white") #4칸 빼면 880
        self.temp2.pack()
        
        #RstMark=PhotoImage(file='resultMark.png',master=self.window2)
        #Correct=PhotoImage(file='correct.png',master=self.window2)
        #Wrong=PhotoImage(file='wrong.png',master=self.window2)
        #RstBg1=PhotoImage(file='result_bg.png',master=self.window2)
        #self.rstMark=Label(self.frame2,image=RstMark,bg="white")
        #self.rstMark.place(x=10,y=140,width=200,height=200)
        #self.rstBg1=Label(self.frame2,image=RstBg1,bg='white')
        #self.rstBg1.place(x=2,y=680,height=190)
    
        #채점 결과 출력
        if len(self.rst) >= 10:
            for i in range(10):
                Label(self.frame2,text=self.EngRdWord[i][1],font=("맑은고딕",15,),bg='white').place(x=300,y=140+50*i)
                if self.rst[i]=='wrong':
                    Label(self.frame2,text=self.rst[i],font=("맑은고딕",15,),fg='red',bg='white').place(x=500,y=140+50*i)
                    Label(self.frame2,text='Wrong',bg='white').place(x=200,y=110+50*i)
                else:
                    Label(self.frame2,text=self.rst[i],font=("맑은고딕",15,),fg='green',bg='white').place(x=500,y=140+50*i)
                    Label(self.frame2,text='Correct',bg='white').place(x=200,y=130+50*i)       
            if len(self.rst) >= 11:
                print("because the words are over 10,so the program just print 10 results of them")    
        else:
            for i in range(len(self.rst)):
                Label(self.frame2,text=self.EngRdWord[i][1],font=("맑은고딕",15,),bg='white').place(x=300,y=140+50*i)
                if self.rst[i]=='wrong':
                    Label(self.frame2,text=self.rst[i],font=("맑은고딕",15,),fg='red',bg='white').place(x=500,y=140+50*i)
                    Label(self.frame2,text='Wrong',bg='white').place(x=200,y=110+50*i)
                else:
                    Label(self.frame2,text=self.rst[i],font=("맑은고딕",15,),fg='green',bg='white').place(x=500,y=140+50*i)
                    Label(self.frame2,text='Correct',bg='white').place(x=200,y=130+50*i)
            
        totalNumofWord=len(self.EngRdWord)
        score=Label(self.frame2,text=str(self.count)+'/'+str(totalNumofWord),font=("HY헤드라인M",40,),fg='green',bg='white')
        score.place(x=650,y=550)
        self.rnwWord()
        self.window2.mainloop()
        
    #단어틀린거는 모르는걸로 이동해야 하므로 갱신이 필요함 
    
    def rnwWord(self):
        
        notKnowList=[]
        knowList=[]
        tempRnw=self.userlist[0].get_notKnow()
        #맞은 단어와 틀린단어를 문자열 형태로 변환
        for i in range(len(self.EngRdWord)):
            if self.rst[i]=='wrong':
                notKnowList.append(str(self.EngRdWord[i][0]))
            else: 
                knowList.append(str(self.EngRdWord[i][0]))
        #아는단어가 데이터 베이스에 하나도 없으면 index오류가 남, 그래서 단어 데이터의 첫번째 단어로 초기화한다. 
        if not knowList:
            print("맞춘단어가 없어 아는단어(know)가 더이상 없습니다. 단어 데이터의 첫번째단어로 초기화합니다.")
            knowList.append('1')
        else:
            print('knowList is not None')
            
        print(notKnowList+tempRnw)
        #print(self.userlist[0].get_userNum())
        s='.'.join(notKnowList+tempRnw)
        print(s)
        s2='.'.join(knowList)
        s3=''.join(self.userlist[0].get_name())
        data=str(self.userlist[0].get_userNum())+","+s3+","+str(self.userlist[0].get_gameTime())+","+s2+","+s
        print(data)
        with open('user.txt','w',encoding='UTF8') as f :  
            f.write(data)
       ##현재 오류    ValueError: invalid literal for int() with base 10: '' ----- 들어있는게 없어서 단어를 못불러옴
              
              
if __name__ == "__main__":
    app = SampleApp()
    app.mainloop()