# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
"""
Created on Thu May  6 15:07:11 2021

@author: jimin
"""
print(Null)