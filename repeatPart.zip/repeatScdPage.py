# -*- coding: utf-8 -*-
"""
Created on Thu May  6 15:08:44 2021

@author: jimin
"""
from tkinter import * #tkinter의 모든 기능을 사용한다. 
import os
from rptWord import RptWord


print(os.path.dirname(os.path.realpath(__file__)))


class repeatScdGui(RptWord): 
    def __init__(self):
        RptWord.__init__(self)
        self.EngRdWord=[]
        self.EngRdWord=self.finalRptWord
        self.writtenWord=[] 
        self.rst=[]
        self.count=0
        self.set_frame()
       
    def set_frame(self):
        self.window =Tk()
        self.window.geometry("1000x800")
        self.window.resizable(False,False) #윈도우 창크기 변경 불가능
        self.frame=Frame(self.window)
        self.frame.pack()
    
        self.bg=Canvas(self.frame,width=880,height=800,bg="#FCD4B4") #4칸 빼면 880
        self.bg.pack()
        
        #배경 구현
        self.rpt_widget1=Label(self.frame,text="복습하기",font=("맑은 고딕",40,),fg="white",bg="#ED7D31",justify="center")
        self.rpt_widget1.place(x=2,y=2,width=880,height=120)
        self.rpt_widget2=Label(self.frame,bg="#ED7D31")
        self.rpt_widget2.place(x=2,y=780,width=880,height=10)
        
        #주의 사항 위젯 구현 
        self.rpt_bg2=Label(self.frame,text="주의: 한글 뜻을 입력한뒤 enter를 눌러주세요",bg="white")
        self.rpt_bg2.place(x=2,y=390,width=880,height=40)
        
           
        #영어 단어위젯 구현
        self.text=StringVar()
        print(self.text.get())
        #초기 영단어 설정
        self.setWord()
        self.wordWidget=Label(self.frame,textvariable=self.text,font=("맑은 고딕",50,),bg="white",justify="center")
        
        
   
        #단어답 입력박스 구현
        self.txtBox=Entry(self.frame,font=("맑은 고딕",30,),fg="#404040",bg="#A6A6A6",justify="center")
        self.txtBox.place(x=10,y=440,width=860,height=210)
        
        #entry 엔터 이벤트 저장으로 처리
        self.txtBox.bind("<Return>",self.save)
        
        #단어 체크를 위해 랜덤으로 설정한 단어들을 프린트해보고 영어단어위젯 위치 선정
        print(self.EngRdWord)
        self.wordWidget.place(x=10,y=130,width=860,height=250)
        
        
        #다시하기 버튼 구현
        RtnToInit=PhotoImage(file="restart.png",master=self.window)
        self.rtnToInit=Button(self.frame,image=RtnToInit,bg="#FCD4B4",justify="center",bd=0)
        self.rtnToInit.place(x=2,y=670,width=200,height=100)
        
        self.window.mainloop()
        
    #처음영어단어 설정하는 메소드    
    def setWord(self):
        while(1):
            self.text.set(self.EngRdWord[0][1]) 
            return 0
    #영어단어 변경하는 메소드
    #엔터를 치면 writtenword에 입력받은 단어를 저장하고 영어단어를 다음 리스트로 변경한다.            
    def save(self,event):
         self.writtenWord.append(str(self.txtBox.get())+'\n')  #비교할때 용이하게
         self.txtBox.delete(0,"end")
         self.resultBtImage=PhotoImage(file="resultBtImage.png",master=self.window)
         self.chgWord()
         print("enter pressed:Saved Complete!")
         print(self.writtenWord)   
    
    def chgWord(self):
        while(1):
            for i in range(len(self.EngRdWord)):
                if self.text.get()==self.EngRdWord[i][1]: 
                    self.text.set(self.EngRdWord[i+1][1])
                    print("nxtWord button pressed:moved to next word!")
                    return 0
                elif self.text.get()==self.EngRdWord[-1][1]:
                #다 끝나면 결과보기가 나타남
                    self.resultBt=Button(self.window,image=self.resultBtImage,bg="#FCD4B4",command=self.result)
                    self.resultBt.place(x=420,y=670,width=150,height=100)
                    print("nxtWord button destoyed:please check the answer")
                    self.cal()
                    return 0
    def cal(self):
         #채점
        for i in range(len(self.EngRdWord)):
            if self.EngRdWord[i][2]==self.writtenWord[i]:
                self.rst.insert(i,'correct')
                self.count=self.count+1
                print('correct')
            else:
                self.rst.insert(i,'wrong')
                print('wrong')           
                
    def result(self):
        self.window2 =Tk()
        self.window2.geometry("800x800")
        self.window2.resizable(False,False) #윈도우 창크기 변경 불가능
        self.frame2=Frame(self.window2)
        self.frame2.pack()
        
        self.rst_widget1=Canvas(self.frame2,width=800,height=100,bg="#3E78ED")
        self.rst_widget1.pack()
        self.rst_widget1.create_text(400,50,fill="white",text="Result",font=("맑은 고딕",30,))
        self.temp2=Canvas(self.frame2,width=800,height=800,bg="white") #4칸 빼면 880
        self.temp2.pack()
        
        RstMark=PhotoImage(file='resultMark.png',master=self.window2)
        Correct=PhotoImage(file='correct.png',master=self.window2)
        Wrong=PhotoImage(file='wrong.png',master=self.window2)
        RstBg1=PhotoImage(file='result_bg.png',master=self.window2)
        self.rstMark=Label(self.frame2,image=RstMark,bg="white")
        self.rstMark.place(x=10,y=140,width=200,height=200)
        self.rstBg1=Label(self.frame2,image=RstBg1,bg='white')
        self.rstBg1.place(x=2,y=680,height=190)
       
        
        #채점 결과 출력
        for i in range(10):
            Label(self.frame2,text=self.EngRdWord[i][1],font=("맑은고딕",15,),bg='white').place(x=300,y=140+50*i)
            if self.rst[i]=='wrong':
                Label(self.frame2,text=self.rst[i],font=("맑은고딕",15,),fg='red',bg='white').place(x=500,y=140+50*i)
                Label(self.frame2,image=Wrong,bg='white').place(x=200,y=110+50*i)
            else:
                Label(self.frame2,text=self.rst[i],font=("맑은고딕",15,),fg='green',bg='white').place(x=500,y=140+50*i)
                Label(self.frame2,image=Correct,bg='white').place(x=200,y=130+50*i)       
        if len(self.rst) >= 11:
            print("because the words are over 10,so the program just print 10 results of them")    
            
        totalNumofWord=len(self.EngRdWord)
        score=Label(self.frame2,text=str(self.count)+'/'+str(totalNumofWord),font=("HY헤드라인M",40,),fg='green',bg='white')
        score.place(x=650,y=550)
        self.window2.mainloop()

    '''    
    def renewUserInfo(self):
        print(self.inttemp)
        #틀렸으면 DB의 아는단어에서 빠지고 모르는 단어로 들어간다. 
        knowofRpt=[]
        notknowofRpt=[]
        for i in range(len(self.rst)): 
            if self.rst[i]=='correct':
                knowofRpt.append
                
    '''            

temp=repeatScdGui()
