#UserInfo.py로 저장하기 ! 사용할때 import UserInfo
#생성시 user=UserInfo.User() 하면 생성된다. 변수들을 직접 건들일 수 없으므로 함수 이용.

class User :
    def __init__(self) :
        #__변수이름은 외부에서 변경 불가능
        self.__name=""
        self.__gameTime=0
        self.__know=list();
        self.__notKnow=list();
        self.__UserNum=0
    
    def set_init(self,num,name,gameTime,know,notKnow):
        self.__UserNum=num
        self.__name=name
        self.__gameTime=gameTime
        self.__know=know.split('.')
        self.__notKnow=notKnow.split('.')
        
    def set_name(self,name) :
        self.__name = name
    def set_gameTime(self,gameTime):
        self.__gameTime=gameTime
    def set_know(self,know):
        self.__know=know
    def set_notKnow(self,know):
        self.__notKnow=know
    
    def get_userNum(self):
        return self.__UserNum
    def get_name(self):
        return self.__name
    def get_gameTime(self):
        return self.__gameTime
    def get_know(self):
        return self.__know
    def get_notKnow(self):
        return self.__notKnow
    
        