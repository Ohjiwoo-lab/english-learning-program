# -*- coding: utf-8 -*-
"""
Created on Thu May  6 15:07:11 2021

@author: jimin
"""
from tkinter import *  #tkinter 를 tk로 줄여서 부름
import os
print(os.path.dirname(os.path.realpath(__file__)))

class repeatInitGui():
    def __init__(self):
        self.set_frame()
    def set_frame(self):     
        self.window =Tk()
        self.window.geometry("1000x800")
        self.window.resizable(False,False) #윈도우 창크기 변경 불가능  
        self.frame=Frame(self.window,bd=1)
        self.frame.pack()
        
        self.bg=Canvas(self.frame,width=880,height=800,bg="white") #4칸 빼면 880
        self.bg.pack()
        rptInitBg1=PhotoImage(file="rptInitbg1.png",master=self.window)
        self.bg.create_image(0,40,anchor='nw',image=rptInitBg1)
        
        self.rptWidget1=Label(self.frame,text="복습하기",font=("맑은 고딕",45,),
                            fg="white",bg="#ED7D31",justify="center")
        self.rptWidget1.place(x=2,y=150,width=880,height=100)
        
        
        
        self.rptWidget3=Label(self.frame,text="사용방법",font=("맑은 고딕",10,),width=10,height=1,bg="#9F9F9F")
        self.rptWidget3.place(x=400,y=250)
        
        explainButton=PhotoImage(file="questionMark.png",master=self.window)
        self.B1=Button(self.frame,image=explainButton,bg="#9F9F9F",command=self.howToUse,bd=0)
        self.B1.place(x=360,y=280)
        
        startButton=PhotoImage(file="rptStartButton.png",master=self.window)
        self.B2=Button(self.frame,image=startButton,bg="#9F9F9F",justify="center",bd=0,command=self.nextpage())
        self.B2.place(x=335,y=380,width=200,height=200)
        self.window.mainloop()
        
    def howToUse(self):
        self.window2=Tk()
        self.window2.geometry("500x400")
        self.window2.resizable(False,False)
        htulabelphoto=PhotoImage(file="howtouse.png",master=self.window2)
        self.htulabel=Label(self.window2,image=htulabelphoto,bg="white")
        self.htulabel.pack()
        self.window2.mainloop()
    def nextpage(self):
        print("button pressed")
 

        

temp=repeatInitGui()