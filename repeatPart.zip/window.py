
"""
Created on Sat Apr 24 19:45:10 2021

@author: jimin
"""

import tkinter as tk
import os

print(os.path.dirname(os.path.realpath(__file__))) #이미지파일을 불러올때 경로안적어도 됨

class User :
    def __init__(self) :#초기값
        self.name="";
        self.point=0;
    def set_name(self,name) :
        self.name=name; #java this.랑 같음.


def backToMenu():
    User.name="";



def set_frame() :
    
    window = tkinter.Tk() #루트 윈도우를 생성
    window.geometry("700x570"); #윈도우 크키 설정
    window.resizable(False,False) #윈도우 창크기 변경 불가능
   
    
   ##이미지가 들어가있는 위젯 만들기
    repeatImage=tkinter.PhotoImage(file="repeat.png",master=window)
    widget1=tkinter.Label(window, image=repeatImage)#윈도우 창에 라벨이라는 위젯 설정
    widget1.pack()
    #위젯을 윈도우에 배치 
    
    repeat_explain=tkinter.PhotoImage(file="repeat_explain.png",master=window)
    widget2=tkinter.Label(window,image=repeat_explain,anchor="center")
    widget2.pack()
        

    #윈도우창에 띄울 버튼의 속성 설정(text,버튼 테두리모양,넓이,버튼이active일때 실행함수,딜레이1초,0.1초마다 버튼 뗄 때까지 실행)
    #뒤로가기버튼
    back=tkinter.Button(window,text="back",overrelief="solid",width=5,command=backToMenu())
    back.place(x=20,y=500)
    #스타트버튼
    start = tkinter.Button(window,text="start",overrelief="solid",width=5) 
    start.place(x=630,y=500)
    
    

    window.mainloop()
    
    
    
set_frame()

 