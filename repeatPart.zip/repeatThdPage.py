# -*- coding: utf-8 -*-
"""
Created on Sun May  9 09:07:19 2021

@author: jimin
"""

import tkinter as tk  #tkinter 를 tk로 줄여서 부름
import os
from repeatScdPage import repeatScdGui

print(os.path.dirname(os.path.realpath(__file__)))


class repeatThdGui(repeatScdGui):
    def __init__(self):
        self.rst=[]
        
        self.set_frame()
        
        
    def set_frame(self):
        self.window =tk.Tk()
        self.window.geometry("1000x800")
        self.window.resizable(False,False) #윈도우 창크기 변경 불가능
        self.frame=tk.Frame(self.window)
        self.frame.pack()
        
        #배경 구현
        self.rpt_widget1=tk.Canvas(self.frame,width=880,height=100,bg="#ED7D31")
        self.rpt_widget1.pack()
        self.rpt_widget1.create_text(440,50,fill="white",text="복습하기",font=("맑은 고딕",30,))
        self.temp2=tk.Canvas(self.frame,width=880,height=800,bg="white") #4칸 빼면 880
        self.temp2.pack()
        
        
        #결과배경위젯 
        RstMark=tk.PhotoImage(file='resultMark.png',master=self.window)
        self.rstMark=tk.Label(self.frame,image=RstMark,bg="white")
        self.rstMark.place(x=10,y=150,width=200,height=200)
        
        self.rstMark2=tk.Label(self.frame,text="Result",font=("맑은 고딕",30,),bg="white"
                               ,width=10,height=1,justify="center")
        self.rstMark2.place(x=320,y=150)
        
        #채점결과 출력
        print("결과를 출력합니다.")
        '''
        for i in range(len(self.temp1)):
            x_loc=400
            y_loc=200
            tk.Label(self.frame,text=self.temp1[i][1],font=("맑은 고딕",15,),width=15,height=1).place(x=x_loc,y=y_loc+10*i)
        '''    
        #실행
        self.window.mainloop()

    #단어 채점
  

a=repeatThdGui()
