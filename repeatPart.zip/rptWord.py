# -*- coding: utf-8 -*-
"""
Created on Tue May 11 11:00:41 2021

@author: jimin
"""

from userManager import UserManager
from wordManager import WordManager

class RptWord(UserManager,WordManager):
    def __init__(self):
        WordManager.__init__(self)
        UserManager.__init__(self)
        self.temp=[]
        self.temp2=[]
        self.wordnum1=[]
        self.finalRptWord=[]
        self.setWordforRpt()
        
    def setWordforRpt(self):
        #첫번째유저의 Know(번호)를 리스트에 저장
        self.temp.append(self.userlist[0].get_know())
        self.inttemp=list(map(int,self.temp[0]))
        print(self.inttemp)
        
        #wordlist의 번호만 리스트에 저장
        for i in range(len(self.wordlist)):
            self.wordnum1.insert(i,self.wordlist[i].get_wordNum())    
        
        #wordlist 전체 2차원 리스트에 저장
        for i in range(len(self.wordlist)):
            self.temp2.insert(i,[self.wordlist[i].get_wordNum(),self.wordlist[i].get_english(),self.wordlist[i].get_korean()])
        
        #inttemp를 이용해서 wordlist의 영어와 한글을 역추적
        for i in range(len(self.inttemp)):
            for j in range(len(self.wordnum1)):
                if self.inttemp[i]==self.wordnum1[j]:
                   self.finalRptWord.insert(i,[self.wordlist[j].get_wordNum(),self.wordlist[j].get_english(),self.wordlist[j].get_korean()])  
                
        print(self.finalRptWord)
